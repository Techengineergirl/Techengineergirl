import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:device_info/device_info.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:pointycastle/export.dart';

userDevice() async {
  var deviceId, deviceKey, key;
  DeviceInfoPlugin dif = new DeviceInfoPlugin();
  AndroidDeviceInfo androidDeviceInfo = await dif.androidInfo;

  Uint8List sha256Digest(Uint8List data) {
    final d = new SHA256Digest();
    return d.process(data);
  }

  try {
    if (Platform.isAndroid) {
      deviceId = androidDeviceInfo.model.toString();
      print('2: $deviceId');
    } else if (Platform.isIOS) {
      IosDeviceInfo iosDeviceInfo = await dif.iosInfo;
      deviceId = iosDeviceInfo.model.toString();
      print('3: $deviceId');
    }
    key = sha256Digest(utf8.encode('$deviceId'));
    deviceKey = base64Encode(key);

    return {'deviceId': deviceId, 'hwKey': deviceKey};
  } catch (exception) {
    print('4: $exception');
    throw Exception(exception);
  }
}

Future<Login> userLogin(String user, String secret) async {
  var deviceData = userDevice();

  print('112: $deviceData');

  String url = 'zero99.ddns.net';

  Map body = {
    'request': {'id': user, 'secret': secret, 'device': deviceData}
  };

  Map<String, String> header = {
    'Content-type': 'application/json; charset=utf-8',
    'Accept': 'application/json',
    'Authorization': 'none'
  };

  //
  try {
    final response = await http.post(
      Uri.http(url, '/login'),
      headers: header,
      body: jsonEncode(body),
      encoding: utf8,
    );

    //
    if (response.statusCode == 200) {
      final result = json.decode(response.body);
      print('7: $result');

      // save data to db ...
      return Login.fromJson(result);
    }
  } catch (exception) {
    print('11: exception caught >> $exception');
    throw Exception(exception);
  }
}

class Login {
  final String session;
  final String token;
  final String username;
  final String email;
  final String lastLogin;

  Login(
      {@required this.session,
      @required this.token,
      @required this.username,
      @required this.email,
      @required this.lastLogin});

  factory Login.fromJson(Map<String, dynamic> jsonData) {
    print('*****, $jsonData');

    for (int i = 0; i < jsonData.length; i++) {
      if (jsonData['$i'] == Null) {
        jsonData['$i'] = 'N/A';
      }
    }

    return Login(
        session: jsonData['session'],
        token: jsonData['token'],
        username: jsonData['username'],
        email: jsonData['email'],
        lastLogin: jsonData['last_login']);
  }
}
