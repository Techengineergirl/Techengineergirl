import 'dart:math';
import 'dart:typed_data';

import 'package:pointycastle/export.dart';

class Pair {
  final String key;
  final String public;
  final String private;

  Pair({this.private, this.public, this.key});

  Map<String, dynamic> toMap() {
    return {'key': key, 'private': private, 'public': public};
  }

  @override
  String toString() {
    return 'Pair{id:$key, private:$private, public:$public}';
  }
}

Future generatePairs() async {
  AsymmetricKeyPair<RSAPublicKey, RSAPrivateKey> generateRSAKeyPair(
      SecureRandom secureRandom) {
    int bitLength = 2048;

    final keyGen = RSAKeyGenerator()
      ..init(ParametersWithRandom(
          RSAKeyGeneratorParameters(BigInt.parse('65537'), bitLength, 64),
          secureRandom));

    final pair = keyGen.generateKeyPair();

    final pub = pair.publicKey as RSAPublicKey;
    final prv = pair.privateKey as RSAPrivateKey;

    return AsymmetricKeyPair<RSAPublicKey, RSAPrivateKey>(pub, prv);
  }

  SecureRandom getSecureRandom() {
    final secureRandom = FortunaRandom();

    final seedSource = Random.secure();
    final seeds = <int>[];
    for (int i = 0; i < 32; i++) {
      seeds.add(seedSource.nextInt(255));
    }
    secureRandom.seed(KeyParameter(Uint8List.fromList(seeds)));

    return secureRandom;
  }

  final pair = generateRSAKeyPair(getSecureRandom());
  final public = pair.publicKey;
  final private = pair.privateKey;
  //print('$pair');
  //print('$private, $public');

  // '$private, $public';
}

/*
Future createTable() async {
  final String table =
      'CREATE TABLE IF NOT EXISTS key_pair(id INTEGER PRIMARY KEY, private TEXT, public TEXT)';
  await init(table);
}

Future<void> writePair(Pair pair) async {
  final String createTable = '';
}

Future showKeys() async {
  final keys = generate();
  if (keys != null) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('$keys'),
      duration: const Duration(seconds: 2),
    ));
  }
}
*/
