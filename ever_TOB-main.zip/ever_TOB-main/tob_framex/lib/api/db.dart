import 'package:flutter/widgets.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

Future init(String table) async {
  WidgetsFlutterBinding.ensureInitialized();

  final Future<Database> database = openDatabase(
      join(await getDatabasesPath(), 'tob.db'), onCreate: (db, version) {
    return db.execute('$table');
  }, version: 1);

  return database;
}
