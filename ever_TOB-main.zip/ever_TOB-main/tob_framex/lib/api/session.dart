class Session {
  final String sessionId;
  final String sessionKey;
  final String session;

  Session(this.session, this.sessionId, this.sessionKey);
}
