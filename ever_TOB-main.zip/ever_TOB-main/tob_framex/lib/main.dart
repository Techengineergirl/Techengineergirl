import 'package:flutter/material.dart';
import 'package:tob_framex/ui/access/login.dart';

void main() async => runApp(MaterialApp(
      theme: ThemeData(
        textTheme: TextTheme(bodyText2: TextStyle()),
        backgroundColor: Colors.white,
        buttonColor: Colors.black,
      ),
      home: Login(),
      debugShowCheckedModeBanner: false,
    ));
