import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class SignUpKit extends StatefulWidget {
  const SignUpKit({Key key}) : super(key: key);

  _SignUpKit createState() => _SignUpKit();
}

class _SignUpKit extends State<SignUpKit> {
  String _value = 'Birth Gender';
  final _ageController = TextEditingController();

  @override
  void initState() {
    _ageController.addListener(() {
      final int age = int.parse(_ageController.text);

      if (age < 18) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('must be 18+ to register'),
          duration: const Duration(seconds: 2),
        ));
      }
      super.initState();
    });

    @override
    void dispose() {
      _ageController.dispose();
      super.dispose();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Material(
        child: Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.blueGrey,
        title: Text('Register', style: TextStyle(color: Colors.white)),
        centerTitle: true,
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              child: DropdownButton(
                  hint: Text(_value),
                  icon: Icon(Icons.arrow_drop_down_outlined),
                  iconSize: 24,
                  elevation: 16,
                  style: TextStyle(color: Colors.blueGrey),
                  underline: Container(height: 2, color: Colors.blueGrey),
                  onChanged: (String value) {
                    setState(() {
                      _value = value;
                    });
                  },
                  items: <String>['Female', 'Male', 'InterSex']
                      .map<DropdownMenuItem<String>>((String value) {
                    return DropdownMenuItem<String>(
                        value: value, child: Text(value));
                  }).toList()),
            ),
            //
            Container(
              padding: EdgeInsets.fromLTRB(80, 10, 80, 10),
              child: Expanded(
                child: TextField(
                  controller: _ageController,
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(), hintText: 'Age',
                    //labelText: 'Age',
                  ),
                ),
              ),
            ),
            //
            Container(
              padding: EdgeInsets.fromLTRB(0, 30, 0, 0),
              child: TextButton(
                child: Text('continue',
                    style: TextStyle(
                        color: Colors.blueGrey,
                        fontSize: 18,
                        fontWeight: FontWeight.normal)),
                onPressed: () {},
              ),
            ),
            //
          ],
        ),
      ),
    ));
  }
}

Widget signUp() {
  return ListView(reverse: true, padding: EdgeInsets.all(10),
      //crossAxisAlignment: CrossAxisAlignment.center,
      //child: Column(
      children: <Widget>[
        Container(
          padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
          child: Column(
            children: <Widget>[
              Icon(
                Icons.whatshot,
                color: Colors.pinkAccent,
                size: 75.0,
              ),
              Text(
                'Sign Up',
                overflow: TextOverflow.ellipsis,
                style: TextStyle(fontSize: 20.0, color: Colors.pinkAccent),
              ),
            ],
          ),
        ),
        Container(
          child: Column(
            children: <Widget>[
              TextField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                      border: UnderlineInputBorder(), labelText: 'Username')),
              TextField(
                keyboardType: TextInputType.visiblePassword,
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Password',
                ),
              ),
            ],
          ),
        ),
        Container(
          child: Column(
            children: <Widget>[
              TextField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'First Name',
                  )),
              TextField(
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Last Name',
                  )),
              TextField(
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Email: example@email.com',
                ),
              ),
              TextField(
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Phone',
                ),
              ),
              TextField(
                keyboardType: TextInputType.numberWithOptions(),
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Age',
                ),
              ),
              TextField(
                decoration: InputDecoration(
                  border: UnderlineInputBorder(),
                  labelText: 'Physical Gender',
                  helperText: '*Required',
                  //errorText: 'This is a required field',
                ),
              )
            ],
          ),
        ),
      ]);
}
