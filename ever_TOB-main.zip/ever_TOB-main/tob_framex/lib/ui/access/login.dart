import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:tob_framex/api/auth.dart';
import 'package:tob_framex/ui/dash.dart';

import 'forgot_passwd.dart';
import 'signup.dart';

class Login extends StatefulWidget {
  const Login({Key key}) : super(key: key);

  _LoginState createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _pwdController = TextEditingController();
  final _userController = TextEditingController();

  bool value = false;
  void _checkBoxStatus(bool changedValue) => setState(() {
        value = changedValue;
      });

  Future<Login> doLogin;

  @override
  void initState() {
    super.initState();
    doLogin =
        userLogin(_userController.text.toString(), _pwdController.text.toString()) as Future<Login>;
  }

  Future doAuth() async {
    Map<String, String> result;

    if (_pwdController.text.isEmpty && _userController.text.isEmpty) {
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('please enter a username and password!')));
    } else {
      result =
          await userLogin(_userController.text.toString(), _pwdController.text.toString()) as Map;
      print('result: $result');

      if (result.isEmpty) {
        ScaffoldMessenger.of(context)
            .showSnackBar(SnackBar(content: Text('incorrect username or password!')));
      } else {
        if (result.containsKey('authenticated') & result.containsValue(true)) {
          Navigator.push(context, MaterialPageRoute(builder: (context) => DashboardPage()));
        } else {
          ScaffoldMessenger.of(context)
              .showSnackBar(SnackBar(content: Text('incorrect username or password!')));
        }
      }
    }
  }

  //biometrics
  final LocalAuthentication auth = LocalAuthentication();
  List<BiometricType> availableList;
  bool checkBio = false;
  String bioList, success, error, msg;

  Future checkBiometrics() async {
    try {
      checkBio = await auth.canCheckBiometrics;
      availableList = await auth.getAvailableBiometrics();
    } on PlatformException catch (e) {
      print('$e');
    }

    setState(() {
      if (checkBio == true) {
        if (availableList.isNotEmpty) {
          availableList.forEach((ab) {
            AlertDialog(
              title: Text('Device Supported Biometrics'),
              content: SingleChildScrollView(
                child: Text('$ab'),
              ),
              actions: [
                Row(
                  children: [
                    TextButton(
                      child: Text('Close'),
                      onPressed: Navigator.of(context).pop,
                    )
                  ],
                )
              ],
            );

            /*
            AlertDialog(
                title: Text('Biometrics Options'),
                content: SingleChildScrollView(
                  child: ListBody(
                    children: <Widget>[Text('$ab')],
                  ),
                ),
                actions: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,

                  ),
                ]);*/
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Available Biometrics: $ab'),
              duration: const Duration(seconds: 2),
            ));
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Biometrics unavailable at this time'),
            duration: const Duration(seconds: 2),
          ));
        }
      } else if (checkBio == false) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text("This Device does not support Biometrics!"),
          duration: const Duration(seconds: 2),
        ));
      } else if (checkBio == null) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content: Text('Biometrics unavailable at this time'),
          duration: const Duration(seconds: 2),
        ));
      }
    });
  }

  /*
  Future availableBiometrics() async {
    availableList = await auth.getAvailableBiometrics();
    try {
      if (availableList.isNotEmpty) {
        availableList.forEach((ab) {
          bioList = '$ab';
        });
      } else {
        bioList = "no biometrics are available";
        //BIOMETRICS ERR
      }
      //return bioList;
    } catch (e) {
      print('$e');
    }
  }
   */

  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);

    return GestureDetector(
        onTap: () {
          FocusScopeNode currentScope = FocusScope.of(context);

          if (!currentScope.hasPrimaryFocus) {
            currentScope.unfocus();
          }
        },
        child: Material(
            child: Scaffold(
                //padding: EdgeInsets.fromLTRB(10, 25, 10, 5),
                resizeToAvoidBottomInset: false,
                body: Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      //logo
                      Container(
                        constraints: BoxConstraints(),
                        child: Icon(
                          Icons.whatshot_outlined,
                          size: 100,
                          color: Colors.blueGrey,
                        ),
                      ),

                      //Form
                      Container(
                          padding: EdgeInsets.all(15),
                          child: Column(
                            children: [
                              TextField(
                                decoration: InputDecoration(
                                  hintText: 'Username',
                                  fillColor: Colors.blueGrey,
                                ),
                                controller: _userController,
                                style: TextStyle(color: Colors.blueGrey),
                                keyboardType: TextInputType.multiline,
                              ),
                              TextField(
                                obscureText: true,
                                decoration: InputDecoration(
                                  hintText: 'Password',
                                  fillColor: Colors.blueGrey,
                                ),
                                controller: _pwdController,
                                style: TextStyle(color: Colors.blueGrey),
                                keyboardType: TextInputType.multiline,
                              )
                            ],
                          )),

                      //biometrics
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Container(
                              child: Row(
                                children: [
                                  Text(
                                    'Remember Me',
                                    style: TextStyle(color: Colors.blueGrey),
                                  ),
                                  Checkbox(
                                    value: value,
                                    onChanged: _checkBoxStatus,
                                  )
                                ],
                              ),
                            ),
                            Builder(
                              builder: (context) => TextButton(
                                onPressed: () {
                                  checkBiometrics();
                                },
                                child: Icon(
                                  Icons.fingerprint_outlined,
                                  size: 40,
                                  color: Colors.blueGrey,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      //register btn
                      Container(
                        padding: EdgeInsets.fromLTRB(10, 10, 10, 10),
                        child: ElevatedButton(
                            onPressed: () {
                              doAuth();
                              /*
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => DashboardPage()));*/
                            },
                            style: ElevatedButton.styleFrom(
                              primary: Colors.blueGrey,
                              textStyle: TextStyle(color: Colors.black),
                              padding: const EdgeInsets.fromLTRB(140, 20, 140, 20),
                            ),
                            child: Text(
                              'LOGIN',
                              textAlign: TextAlign.center,
                              //overflow: TextOverflow.ellipsis,
                            )),
                      ),

                      //Other
                      Container(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              padding: EdgeInsets.all(10.0),
                              child: TextButton(
                                onPressed: () {
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (context) => ForgotPassword()));
                                },
                                child: Text(
                                  'Forgot Password',
                                  style: TextStyle(
                                      fontSize: 16,
                                      fontStyle: FontStyle.values[0],
                                      fontWeight: FontWeight.w300,
                                      color: Colors.blueGrey),
                                ),
                              ),
                            ),
                            Container(
                                padding: EdgeInsets.all(10.0),
                                child: TextButton(
                                    onPressed: () {
                                      Navigator.push(context,
                                          MaterialPageRoute(builder: (context) => SignUpKit()));
                                    },
                                    child: Text(
                                      'Register',
                                      style: TextStyle(
                                          fontSize: 16,
                                          fontStyle: FontStyle.values[0],
                                          fontWeight: FontWeight.w300,
                                          color: Colors.blueGrey),
                                    )))
                          ],
                        ),
                      ),
                    ],
                  ),
                ))));
  }
}
