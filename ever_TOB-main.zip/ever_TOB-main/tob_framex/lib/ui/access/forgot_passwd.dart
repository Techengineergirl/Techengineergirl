import 'package:flutter/material.dart';

class ForgotPassword extends StatefulWidget {
  const ForgotPassword({Key key}) : super(key: key);

  @override
  _ForgotPassword createState() => _ForgotPassword();
}

class _ForgotPassword extends State<ForgotPassword> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            'Password Reset',
            style: TextStyle(color: Colors.white),
          ),
          centerTitle: true,
          backgroundColor: Colors.blueGrey,
          iconTheme: IconThemeData(color: Colors.white),
          //textTheme: TextTheme(Colors.black),
        ),
        body: Center(
          child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                /*
                Container(
                  padding: EdgeInsets.all(10),
                  child: Text(
                    'enter email to request reset',
                    style: TextStyle(fontSize: 20),
                  ),
                ),*/
                Container(
                  padding: EdgeInsets.all(10),
                  child: TextField(
                    cursorColor: Colors.blueGrey,
                    obscureText: false,
                    decoration: InputDecoration(
                        labelText: 'Email Address',
                        fillColor: Colors.blueGrey,
                        focusedBorder: UnderlineInputBorder(
                            borderSide: const BorderSide(width: 0.0)),
                        enabledBorder: const UnderlineInputBorder(
                          borderSide: const BorderSide(width: 0.0),
                        )),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(10),
                  child: ElevatedButton(
                    onPressed: () {},
                    style: ElevatedButton.styleFrom(
                      primary: Colors.blueGrey,
                      textStyle: TextStyle(color: Colors.white),
                      padding: const EdgeInsets.fromLTRB(60, 20, 60, 20),
                    ),
                    child: Text(
                      'send request',
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                )
              ]),
        ),
      ),
    );
  }
}
