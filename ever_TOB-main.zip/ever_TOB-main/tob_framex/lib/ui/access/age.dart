import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import 'signup.dart';

class CheckAge extends StatefulWidget {
  CheckAge({Key key}) : super(key: key);

  @override
  _CheckAgeState createState() => _CheckAgeState();
}

class _CheckAgeState extends State<CheckAge> {
  bool checkBoxValue = false;
  String boxTitle = 'select if you are 18 or older';
  String errorMessage = 'Please check the box to certify your age!';

  var selected = MaterialPageRoute(builder: ((context) => SignUpKit()));
  var register = MaterialPageRoute(builder: ((context) => CheckAge()));

  void _checkboxStatus(bool changedValue) => setState(() {
        checkBoxValue = changedValue;
      });

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.pinkAccent,
          title: Center(child: Text('Confirm Age!')),
        ),
        body: SafeArea(
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 30, 10, 40),
            child: Column(
              children: <Widget>[
                Container(
                  padding: EdgeInsets.fromLTRB(0, 15, 0, 15),
                  child: Text(
                    'YOU MUST BE 18 TO PROCEED',
                    style: TextStyle(color: Colors.pinkAccent, fontSize: 20.0),
                  ),
                ),
                Center(
                  child: CheckboxListTile(
                    title: Text(
                      boxTitle,
                      style: TextStyle(color: Colors.pinkAccent),
                    ),
                    value: checkBoxValue,
                    activeColor: Colors.pinkAccent,
                    onChanged: _checkboxStatus,
                  ),
                ),
                Container(
                  padding: EdgeInsets.fromLTRB(0, 40, 0, 20),
                  child: ElevatedButton(
                    onPressed: () {
                      if (checkBoxValue == true) {
                        Navigator.push(context, selected);
                      }
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Colors.pinkAccent,
                      textStyle: TextStyle(color: Colors.white),
                      padding: const EdgeInsets.fromLTRB(50, 15, 50, 15),
                    ),
                    child: Text(
                      'Continue',
                      textAlign: TextAlign.center,
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.all(20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Container(
                          child: TextButton(
                        onPressed: () {
                          /*
                          Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (context) => AgePolicy()));*/
                        },
                        child: Text(
                          'Age Policy',
                          style: TextStyle(
                              fontStyle: FontStyle.normal,
                              color: Colors.pinkAccent,
                              fontSize: 20,
                              fontWeight: FontWeight.w300),
                        ),
                      )),
                    ],
                  ),
                ),
                Container(
                  //padding: EdgeInsets.all(10),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Container(
                        child: TextButton(
                          onPressed: () {
                            /*
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => PrivacyPolicy()));*/
                          },
                          child: Text(
                            'Privacy',
                            style: TextStyle(
                                fontStyle: FontStyle.normal,
                                color: Colors.pinkAccent,
                                fontSize: 15,
                                fontWeight: FontWeight.w300),
                          ),
                        ),
                      ),
                      Container(
                        child: TextButton(
                          onPressed: () {
                            /*Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => TermsPolicy()));*/
                          },
                          child: Text(
                            'Terms',
                            style: TextStyle(
                                fontStyle: FontStyle.normal,
                                color: Colors.pinkAccent,
                                fontSize: 15,
                                fontWeight: FontWeight.w300),
                          ),
                        ),
                      ),
                      Container(
                        child: TextButton(
                          onPressed: () {
                            /*
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) => LegalPolicy()));*/
                          },
                          child: Text(
                            'Legal',
                            style: TextStyle(
                                fontStyle: FontStyle.normal,
                                color: Colors.pinkAccent,
                                fontSize: 15,
                                fontWeight: FontWeight.w300),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
