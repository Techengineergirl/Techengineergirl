import 'package:flutter/material.dart';

import 'access/login.dart';
import 'nav/bottom/match.dart';
import 'nav/bottom/message.dart';
import 'nav/bottom/profile.dart';
import 'nav/notifications.dart';
import 'nav/rendezvous.dart';
import 'nav/settings.dart';
import 'nav/tips.dart';

class DashboardPage extends StatefulWidget {
  DashboardPage({Key key}) : super(key: key);

  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  int _selectedPageTab = 0;
  int currentPage = 0;

  List<Widget> _tabbedPageList = <Widget>[
    Home(),
    MatchPage(),
    MessagePage(),
    ProfilePage()
  ];

  void _itemTapped(int index) {
    setState(() {
      _selectedPageTab = index;
      Center(child: _tabbedPageList.elementAt(_selectedPageTab));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        bottomNavigationBar: BottomNavigationBar(
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
              icon: Icon(Icons.home),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.favorite_border),
              label: 'Match',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_bubble_outline),
              label: 'Messages',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.perm_identity),
              label: 'Profile',
            )
          ],
          currentIndex: _selectedPageTab,
          unselectedItemColor: Colors.pinkAccent,
          selectedItemColor: Colors.pink,
          onTap: _itemTapped,
        ),
        body: Center(
          child: _tabbedPageList.elementAt(_selectedPageTab),
        ));
  }
}

//HOME PAGE DESIGN
class Home extends StatefulWidget {
  Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Material(
        child: Scaffold(
            appBar: AppBar(
              title: Center(
                child: Text('Home'),
              ),
              backgroundColor: Colors.pinkAccent,
            ),
            drawer: Drawer(
              child: ListView(
                children: <Widget>[
                  Container(
                    child: UserAccountsDrawerHeader(
                      accountName: Text("legodude20",
                          style: TextStyle(color: Colors.white, fontSize: 20)),
                      accountEmail: Text('iamthelego20@notlegos.com',
                          style: TextStyle(color: Colors.white70)),
                      currentAccountPicture: CircleAvatar(
                        backgroundImage: NetworkImage(
                            'https://randomuser.me/api/portraits/lego/5.jpg'),
                      ),
                      decoration: BoxDecoration(color: Colors.pinkAccent),
                      //onDetailsPressed: ,
                    ),
                  ),
                  Container(
                    child: ListTile(
                      leading: Icon(Icons.notifications, color: Colors.black54),
                      title: Text(
                        'Notifications',
                        style: TextStyle(color: Colors.black87, fontSize: 15),
                      ),
                      onTap: () {
                        Navigator.of(context);
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                NotificationsPage()));
                      },
                    ),
                  ),
                  Container(
                    child: ListTile(
                      leading: Icon(Icons.beach_access, color: Colors.black54),
                      title: Text('Rendezvous',
                          style:
                              TextStyle(color: Colors.black87, fontSize: 15)),
                      onTap: () {
                        Navigator.of(context);
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                RendevzvousPage()));
                      },
                    ),
                  ),
                  Container(
                    child: ListTile(
                      leading: Icon(Icons.info, color: Colors.black54),
                      title: Text(
                        'Tips',
                        style: TextStyle(color: Colors.black87, fontSize: 15),
                      ),
                      onTap: () {
                        Navigator.of(context);
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => TipsPage()));
                      },
                    ),
                  ),
                  Container(
                    child: ListTile(
                      leading: Icon(Icons.settings, color: Colors.black54),
                      title: Text(
                        'Settings',
                        style: TextStyle(color: Colors.black87, fontSize: 15),
                      ),
                      onTap: () {
                        Navigator.of(context);
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => SettingsPage()));
                      },
                    ),
                  ),
                  ListTile(
                      leading:
                          Icon(Icons.power_settings_new, color: Colors.black54),
                      title: Text(
                        'logout',
                        style: TextStyle(
                            color: Colors.black,
                            fontSize: 20,
                            fontWeight: FontWeight.w300),
                      ),
                      onTap: () {
                        Navigator.pop(context);
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => Login()));
                      })
                ],
              ),
            ),
            body: Center(child: Text('Homepage'))));
  }
}
