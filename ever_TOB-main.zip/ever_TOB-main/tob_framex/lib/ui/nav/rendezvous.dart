import 'package:flutter/material.dart';

class RendevzvousPage extends StatefulWidget {
  RendevzvousPage({Key key}) : super(key: key);

  @override
  _RendevzvousPageState createState() => _RendevzvousPageState();
}

class _RendevzvousPageState extends State<RendevzvousPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('Rendezvous')),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Center(
        child: Text('This is the Rendezvous Page ...'),
      ),
    );
  }
}
