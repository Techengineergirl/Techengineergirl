import 'package:flutter/material.dart';

class TipsPage extends StatefulWidget {
  TipsPage({Key key}) : super(key: key);

  @override
  _TipsPageState createState() => _TipsPageState();
}

class _TipsPageState extends State<TipsPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text('Tips')),
        backgroundColor: Colors.pinkAccent,
      ),
      body: Center(
        child: Text('This is the Tips Page ...'),
      ),
    );
  }
}
