import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

class ProfileData {
  final String profileBanner, profileImage, userAbout, userName, gender;
  final String names,
      age,
      email,
      userPhone,
      matches,
      messageCount,
      notifications;

  ProfileData(
      {this.profileBanner,
      this.profileImage,
      this.userName,
      this.names,
      this.gender,
      this.age,
      this.email,
      this.userPhone,
      this.userAbout,
      this.matches,
      this.messageCount,
      this.notifications});

  static final List<ProfileData> profileDataList = [
    ProfileData(
        profileBanner: 'https://i.picsum.photos/id/867/700/500.jpg',
        profileImage: 'https://randomuser.me/api/portraits/lego/5.jpg',
        names: 'Lego Dude',
        userName: '@legodude20',
        age: '21',
        gender: 'genderless',
        email: 'iamthelego20@notlegos.com',
        messageCount: ' 0',
        matches: ' 3',
        notifications: '9',
        userPhone: '200-100-1000',
        userAbout: 'The application will provide you with a JSON, XML, CSV, '
            'or YAML object that you can parse and apply to your '
            'application. You can specify the format you want the '
            'results in using the format parameter.')
  ];
}

class ProfilePage extends StatefulWidget {
  ProfilePage({Key key}) : super(key: key);

  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.supervised_user_circle, color: Colors.white),
        backgroundColor: Colors.pinkAccent,
        title: Center(
          child: Text('Profile', style: TextStyle(color: Colors.white)),
        ),
        actions: <Widget>[
          IconButton(
            icon: const Icon(Icons.more_vert, color: Colors.white),
            tooltip: 'profile settings',
            onPressed: () {},
          ),
        ],
      ),
      body: Container(
        child: ListView.builder(
          itemCount: ProfileData.profileDataList.length,
          itemBuilder: (context, index) {
            ProfileData _profileData = ProfileData.profileDataList[index];

            return Container(
              child: Column(
                children: <Widget>[
                  Container(
                    padding: EdgeInsets.all(10),
                    child: Column(
                      children: <Widget>[
                        CircleAvatar(
                          backgroundImage:
                              NetworkImage(_profileData.profileImage),
                          minRadius: 30,
                          maxRadius: 50,
                          backgroundColor: Colors.white70,
                        ),
                        Container(
                          padding: EdgeInsets.fromLTRB(0, 20, 0, 0),
                          child: Text(_profileData.names,
                              style:
                                  TextStyle(fontSize: 20, color: Colors.black)),
                        ),
                        Container(
                          child: Text(_profileData.userName,
                              style: TextStyle(
                                  fontSize: 15, color: Colors.black54)),
                        ),
                      ],
                    ),
                  ),
                  Card(
                    margin: EdgeInsets.all(10),
                    //color: Colors.pinkAccent,
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: <Widget>[
                        Column(
                          children: <Widget>[
                            Icon(Icons.favorite_border,
                                color: Colors.black, size: 30),
                            Text(_profileData.matches,
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black54,
                                    fontWeight: FontWeight.w300)),
                          ],
                        ),
                        Column(
                          children: <Widget>[
                            Icon(Icons.chat_bubble_outline,
                                color: Colors.black, size: 30),
                            Text(_profileData.messageCount,
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black54,
                                    fontWeight: FontWeight.w300)),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Icon(Icons.notifications_none,
                                color: Colors.black, size: 30),
                            Text(_profileData.notifications,
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black54,
                                    fontWeight: FontWeight.w300)),
                          ],
                        ),
                        Column(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: <Widget>[
                            Icon(Icons.info_outline,
                                color: Colors.black, size: 30),
                            Text('0',
                                style: TextStyle(
                                    fontSize: 20,
                                    color: Colors.black54,
                                    fontWeight: FontWeight.w300))
                          ],
                        )
                      ],
                    ),
                  ),
                  Container(
                    padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: <Widget>[
                        Container(
                            padding: EdgeInsets.all(10),
                            child: Column(
                              children: <Widget>[
                                Icon(Icons.mail_outline,
                                    color: Colors.black54, size: 20),
                                Divider(),
                                Icon(Icons.phone_iphone,
                                    color: Colors.black54, size: 20),
                                Divider(),
                                Icon(Icons.perm_contact_calendar,
                                    color: Colors.black54, size: 20),
                                Divider(),
                                Icon(Icons.people_outline,
                                    color: Colors.black54, size: 20),
                              ],
                            )),
                        Container(
                            padding: EdgeInsets.all(20),
                            child: Column(
                              children: <Widget>[
                                Text(_profileData.email,
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16)),
                                Divider(),
                                Text(_profileData.userPhone,
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16)),
                                Divider(),
                                Text(_profileData.age,
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16)),
                                Divider(),
                                Text(_profileData.gender,
                                    style: TextStyle(
                                        color: Colors.black, fontSize: 16)),
                              ],
                            )),
                      ],
                    ),
                  ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }
}
