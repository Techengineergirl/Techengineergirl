import 'package:flutter/material.dart';

import 'chat.dart';

//import 'file:///C:/Users/parrot-pc/Documents/FlutterDigs/tob/lib/interface/nav-bottom/_chat.dart';

class MessageModel {
  final int messageIndex;
  final String avatar;
  final String corespondent;
  final String lastMessageDateTime;
  final String lastMassage;

  MessageModel(
      {this.messageIndex,
      this.avatar,
      this.corespondent,
      this.lastMessageDateTime,
      this.lastMassage});

  static final List<MessageModel> dummyData = [
    MessageModel(
      messageIndex: 1,
      avatar: "https://randomuser.me/api/portraits/women/34.jpg",
      corespondent: "Laurent",
      lastMessageDateTime: "20:18",
      lastMassage: "How about meeting tomorrow?",
    ),
    MessageModel(
      avatar: "https://randomuser.me/api/portraits/women/49.jpg",
      corespondent: "Tracy",
      lastMessageDateTime: "19:22",
      lastMassage: "I love that idea, it's great!",
    ),
    MessageModel(
      avatar: "https://randomuser.me/api/portraits/women/77.jpg",
      corespondent: "Claire",
      lastMessageDateTime: "14:34",
      lastMassage: "I wasn't aware of that. Let me check",
    ),
    MessageModel(
      avatar: "https://randomuser.me/api/portraits/men/81.jpg",
      corespondent: "Joe",
      lastMessageDateTime: "11:05",
      lastMassage: "Flutter just release 1.0 officially. Should I go for it?",
    ),
    MessageModel(
      avatar: "https://randomuser.me/api/portraits/men/83.jpg",
      corespondent: "Mark",
      lastMessageDateTime: "09:46",
      lastMassage: "It totally makes sense to get some extra day-off.",
    ),
    MessageModel(
      avatar: "https://randomuser.me/api/portraits/men/85.jpg",
      corespondent: "Williams",
      lastMessageDateTime: "08:15",
      lastMassage: "It has been re-scheduled to next Saturday 7.30pm",
    )
  ];
}

class MessagePage extends StatefulWidget {
  MessagePage({Key key}) : super(key: key);

  @override
  _MessagePageState createState() => _MessagePageState();
}

class _MessagePageState extends State<MessagePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          leading: Icon(Icons.mode_comment),
          backgroundColor: Colors.pinkAccent,
          title: Center(child: Text('Messages')),
          actions: <Widget>[
            IconButton(
                icon: const Icon(Icons.more_vert),
                tooltip: 'Message Settings',
                onPressed: () {})
          ]),
      body: Container(
        padding: EdgeInsets.fromLTRB(0, 10, 0, 0),
        child: ListView.builder(
            itemCount: MessageModel.dummyData.length,
            itemBuilder: (context, index) {
              MessageModel _model = MessageModel.dummyData[index];

              return Column(
                children: <Widget>[
                  ListTile(
                    leading: CircleAvatar(
                      radius: 25.0,
                      backgroundImage: NetworkImage(_model.avatar),
                    ),
                    title: Text(_model.corespondent),
                    subtitle: Text(_model.lastMassage),
                    trailing: Column(children: <Widget>[
                      Text(_model.lastMessageDateTime),
                      Icon(Icons.arrow_forward_ios, size: 16)
                    ]),
                    onTap: () {
                      Navigator.of(context);
                      Navigator.of(context).push(MaterialPageRoute(
                          builder: (BuildContext context) => ChatPage()));
                    },
                  ),
                  Divider(height: 24)
                ],
              );
            }),
      ),
    );
  }
}
