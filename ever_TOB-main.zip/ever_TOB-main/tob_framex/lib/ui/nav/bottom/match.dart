import 'package:flutter/material.dart';

class MatchPage extends StatefulWidget {
  MatchPage({Key key}) : super(key: key);

  @override
  _MatchPageState createState() => _MatchPageState();
}

class _MatchPageState extends State<MatchPage> {
  @override
  Widget build(BuildContext context) {
    return Material(
      child: Scaffold(
        appBar: AppBar(
          leading: Icon(Icons.favorite),
          backgroundColor: Colors.pinkAccent,
          title: Center(child: Text('Match')),
          actions: <Widget>[
            IconButton(
                icon: const Icon(Icons.more_vert),
                tooltip: 'Match Settings',
                onPressed: () {})
          ],
        ),
        body: Center(
          child: Text('Match'),
        ),
      ),
    );
  }
}
