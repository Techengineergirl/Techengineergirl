import 'package:flutter/material.dart';

class ChatPage extends StatefulWidget {
  ChatPage({Key key}) : super(key: key);

  @override
  _ChatPageState createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Column(
            children: <Widget>[
              Center(
                child: Icon(Icons.supervised_user_circle, size: 38),
              ),
              Center(
                  child: Text('username',
                      style: TextStyle(
                          fontWeight: FontWeight.w200, fontSize: 16))),
            ],
          ),
          actions: <Widget>[
            IconButton(
                icon: const Icon(Icons.more_vert),
                tooltip: 'Chat Settings',
                onPressed: () {})
          ],
          backgroundColor: Colors.pinkAccent,
        ),
        body: Center(child: Text('Chat')));
  }
}
