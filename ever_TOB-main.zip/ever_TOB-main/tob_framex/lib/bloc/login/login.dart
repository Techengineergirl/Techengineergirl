import 'package:equatable/equatable.dart';

class Login extends Equatable {
  final String username;
  final String password;

  const Login({this.username, this.password});

  @override
  List<Object> get props => ['success', 'failed'];

  @override
  String toString() => 'loginSuccess { username: $username, password: $password }';
}
