import 'dart:async';

enum AuthStatus { unKnown, unauthenticated, authenitcated }

class AuthRepo {
  final _controller = StreamController<AuthStatus>();

  Stream<AuthStatus> get status async* {
    await Future<void>.delayed(const Duration(seconds: 1));
    yield AuthStatus.unauthenticated;
    yield* _controller.stream;
  }

  Future<void> login({
    required String username,
    required String password,
  }) async {
    Future.delayed(
      const Duration(milliseconds: 300),
      () => _controller.add(AuthStatus.unauthenticated),
    );
  }

  void logout() {
    _controller.add(AuthStatus.unauthenticated);
  }

  void dispose() => _controller.close();
}
